sudo apt-get install git -y && git clone https://github.com/JayWu7/TMP.git && cd TMP

cd TMP/ && git pull && pkill python3 
vim bpx-api-py/bpx/bp_bot.py
nohup bash bp_env.sh  &
ps aux | less