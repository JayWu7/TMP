__title__ = "bpx-api-python"
__description__ = "Backpack Exchange api for python"
__version__ = "0.0.1"
__build__ = 0x000001
__author__ = "syp25815"
__author_email__ = "syp25815@gmail.com"
