import time
import random
import logging
from bpx import BpxClient
from bpx_pub import *
import sys

# 初始化日志记录
# logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# 预定义的资产对列表
asset_pairs = ['SOL_USDC', 'PYTH_USDC', 'JTO_USDC', 'JUP_USDC', 'WIF_USDC', 'HNT_USDC', 'RENDER_USDC']

# 初始化BPX客户端
bpx = BpxClient()
pub_key = ''
scr_key = ''
index = int(sys.argv[1])

with open('api.txt', 'r') as fr:
    for i, line in enumerate(fr.readlines()):
        if i == index:
            pub_key, scr_key, _ = line.strip().split()
            break

bpx.init(pub_key, scr_key)

def get_usdc_balance(bpx_client):
    """获取USDC余额"""
    balances = bpx_client.balances()
    return float(balances['USDC']['available'])

def get_latest_price(asset_pair):
    """获取最新市场价格"""
    market_data = recentTrades(asset_pair, 1)
    return float(market_data[0]['price'])

def get_asset_quantity(bpx_client, asset):
    """获取特定资产的数量"""
    balances = bpx_client.balances()
    for token in balances:
        if token == asset:
            return float(balances[token]['available'])
    return 0

def trade_asset():
    while True:
        try:
            # 随机选择一个资产对进行交易
            selected_asset_pair = random.choice(asset_pairs)
            # logging.info(f"选中的资产对: {selected_asset_pair}")

            # 获取USDC余额
            usdc_balance = get_usdc_balance(bpx)
            # logging.info(f"USDC余额: {usdc_balance}")

            # 获取最新市场价格
            latest_price = get_latest_price(selected_asset_pair)
            # logging.info(f"{selected_asset_pair}的最新价格: {latest_price}")

            # 计算购买数量
            if selected_asset_pair == 'SOL_USDC':
                buy_amount = round((usdc_balance / latest_price) * 0.9, 2)
            else:
                buy_amount = round((usdc_balance / latest_price) * 0.7, 1)
            # logging.info(f"计划购买数量: {buy_amount}")
            # 执行市价购买操作
            try:
                buy_result = bpx.ExeOrder(selected_asset_pair, 'Bid', 'Limit', 'GTC', str(buy_amount), str(round(latest_price * 1.1, 2)))
                # logging.info(f"市价购买结果: {buy_result}")
            except:
                pass
            

            # 等待1分钟
            time.sleep(35)

            # 获取特定资产的全部数量，准备卖出
            asset = selected_asset_pair.split('_')[0]  # 假设资产对格式为 'ASSET_USDC'
            sell_amount = get_asset_quantity(bpx, asset)
            # logging.info(f"准备卖出数量: {sell_amount}")

            # 执行市价卖出操作
            try:
                sell_result = bpx.ExeOrder(selected_asset_pair, 'Ask', 'Limit', 'GTC', str(round(sell_amount*0.99, 1)), str(round(latest_price * 0.9, 2)))
                # logging.info(f"市价卖出结果: {sell_result}")
            except:
                pass
            
        except Exception as e:
            # logging.error(f"交易过程中出现错误: {e}")

        # 等待一段时间后再次执行交易循环
        time.sleep(35)

if __name__ == '__main__':
    trade_asset()
